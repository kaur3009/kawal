import {glass} from '../../app/glass'

export const data:glass[]=[
    {type:'Glass1',make:'Honda2019',country:'Newzeland'},
    {type:'Glass2',make:'Toyota2018',country:'India'},
    {type:'Glass3',make:'BMW2017',country:'Australia'},
    {type:'Glass4',make:'Audi2018',country:'Canada'}
];