export interface glass{
    type:string;
    make:string;
    country:string;
}