import { Injectable } from '@angular/core';
import {glass} from '../app/glass'
import {data} from '../../src/assets/Data/data'


@Injectable({
  providedIn: 'root'
})
export class GlassServiceService {

  constructor() { }
  getdata():glass[]{
    return data;
   }
}
