import { Component } from '@angular/core';
import {glass} from '../app/glass'
import {data} from '../../src/assets/Data/data'
import {GlassServiceService} from '../../src/app/glass-service.service'



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Kawal';
  info:glass[];
  constructor(private pService: GlassServiceService) {}
  ngOnInit(): void {
  this.getdata();
}
getdata(): void {
  this.info = this.pService.getdata();
}
}
